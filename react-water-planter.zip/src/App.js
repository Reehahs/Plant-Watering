import WaterBTN from './components/WaterBTN';
import Timer from './components/Timer';
import PlantImg from './components/PlantImg';
import Message from './components/Message';
import { connect } from 'react-redux';

const wateringMessaging = (isTrue) => {
  if (isTrue) {
    return `WOW plant is feeling healthy🥦🦾`;
  }
  else {
    console.log("checking to see text")
    return 'Water your plants! 💦🌱';
  }
}
var text;

const App = (props) => {
  //text = wateringMessaging(props.isWatered)
  return (
    <div className="container">
      <div className='timerList'>
        <Timer hours={'6'} id={'1'} />
        <Timer hours={'6'} id={'2'} />
        <Timer hours={'6'} id={'3'} />
        <Timer hours={'6'} id={'4'} />
        <Timer hours={'6'} id={'5'} />
      </div>

      <div className='pictureList'>
        <PlantImg url={props.url} text={'1'} />
        <PlantImg url={props.url} text={'2'} />
        <PlantImg url={props.url} text={'3'} />
        <PlantImg url={props.url} text={'4'} />
        <PlantImg url={props.url} text={'5'} />
      </div>

      <div className='btnList'>
        <WaterBTN text='1' />
        <WaterBTN text='2' />
        <WaterBTN text='3' />
        <WaterBTN text='4' />
        <WaterBTN text='5' />
      </div>

      <div>
        <Message text={props.Message} />
      </div>
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    isWatering: state.isWatered,
    id: state.id,
    text: state.Message,
    url: state.url
  }
}

export default connect(mapStateToProps)(App)
