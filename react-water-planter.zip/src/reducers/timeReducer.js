﻿const timer = (state = { date: new Date() }, action) => {
    switch (action.type) {
        case 'Reset':
            state.date.setHours(6, 0, 0, 0);
            return state;
        case 'Tick':
            state.date.setSeconds(-1);
            return state;
        default:
            return state;
    }
}

export default timer;