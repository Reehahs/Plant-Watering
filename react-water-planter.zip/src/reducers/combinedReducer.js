﻿import waterReducer from './WaterReducer';
import { combineReducers } from 'redux';
import timer from './timeReducer';

const allReducers = combineReducers({
    timer: timer,
    isWatered: waterReducer,
});

export default allReducers