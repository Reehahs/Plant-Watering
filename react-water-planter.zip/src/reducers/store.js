import thunk from "redux-thunk"
import allReducer from './combinedReducer'
import { createStore, applyMiddleware } from 'redux';

const store = createStore(allReducer, {}, applyMiddleware(thunk));

export default store 