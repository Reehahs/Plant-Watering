﻿const intialState = {
    isWatered: false,
    id: '0',
};
const waterReducer = (state = intialState, action) => {
    switch (action.type) {
        case 'WATERING':
            console.log("water")

            return {
                ...state,
                isWatered: true,
                id: action.id,
                message: 'WOW plant is feeling healthy🥦🦾',
                url: 'https://www.iconpacks.net/icons/2/free-plant-icon-1573-thumb.png'
            }
                ;

        case 'NEEDS_WATERING':
            return {
                ...state,
                isWatered: false,
                id: action.id,
                message: 'Water your plants! 💦🌱',
                url: 'https://st2.depositphotos.com/37234762/45334/v/380/depositphotos_453347394-stock-illustration-dying-plant-pot-isolated-white.jpg'
            }
        default:
            return state;
    }

};

export default waterReducer;