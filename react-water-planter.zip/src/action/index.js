﻿export const wateringAction = (id) => {
    return (dispatch) => {
        console.log("Button Clicked " + id);
        dispatch(requestWatering(id));
        sleep(10000)
            .then(() => console.log(id))
            .then(() => dispatch(reset(id)))
            .then(() => dispatch(needsWatering(id)))
    }
}

export const clockTicking = (id) => {
    return (dispatch) => {

        setInterval(() => {
            dispatch(ticking(id))
            console.log("ITS TICKING time")
        }, 1000);
    }
}
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}


const reset = (id) => {
    return (dispatch) => {
        dispatch({
            type: 'RESET',
            id,
        })

    }
}

const ticking = (id) => {
    return (dispatch) => {
        dispatch({
            type: 'TICK',
            id,
        })

    }
}


const requestWatering = (id) => {
    return (dispatch) => {
        dispatch({
            type: 'WATERING',
            id,
        })

    }
}



export const needsWatering = (id) => {
    return (dispatch) => {
        dispatch({
            type: 'NEEDS_WATERING',
            id
        })
    }
}