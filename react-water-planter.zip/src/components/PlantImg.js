import PropTypes from 'prop-types';
import { connect } from 'react-redux'
const urlPlant = 'https://www.iconpacks.net/icons/2/free-plant-icon-1573-thumb.png';
const urlDeadPlant = 'https://st2.depositphotos.com/37234762/45334/v/380/depositphotos_453347394-stock-illustration-dying-plant-pot-isolated-white.jpg';
let urlSupplied = urlDeadPlant;


const urlChanger = (props) => {
    if (props.isWatered /*&& (props.id == props.text)*/) {
        console.log(props.isWatered)
        urlSupplied = urlPlant;
    }
}

const PlantImg = (props) => {
    urlChanger(props);
    return (
        <div className='plant'>
            <img className='pic' src={props.url} />
            <div className='label'>
                Plant {props.text}
            </div>

        </div>
    )
}

PlantImg.defaultProps = {
    url: urlPlant,
    text: 'Plant 0'
}

PlantImg.prototype = {

    text: PropTypes.string,
}

const mapStateToProps = state => ({
    isWatered: state.isWatered,
    id: state.id
})


export default connect(mapStateToProps)(PlantImg)