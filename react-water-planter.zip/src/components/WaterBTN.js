import PropTypes from 'prop-types';
import { wateringAction } from '../action';
import { connect } from 'react-redux'


const WaterBTN = (props) => {
    return (
        <button onClick={props.water} className='btn'>
            Water Plant {props.text}
        </button>

    )
}
WaterBTN.defaultProps = {
    text: '0'
}

WaterBTN.propTypes = {
    text: PropTypes.string,
}


const mapStateToProps = (state) => {
    return {
        isWatering: state.isWatered,
        id: state.id
    }
}

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        water: () => dispatch(wateringAction(ownProps.text))
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(WaterBTN)