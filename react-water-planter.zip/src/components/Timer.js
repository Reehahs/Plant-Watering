import { clockTicking } from '../action';
import { connect } from 'react-redux'
const Timer = (props) => {
    //props.hours = convertDateToString(props);
    return (
        <div className="timer">
            <p>
                {props.hours}:0:0
            </p>
        </div>
    )
}
// const convertDateToString = (props) => {
//     return [
//         Math.floor(props.date.getSeconds() / 60 / 60),
//         Math.floor(props.date.getSeconds() / 60 % 60),
//         Math.floor(props.date.getSeconds() % 60)
//     ]
//         .join(":")
//         .replace(/\b(\d)\b/g, "0$1")
// }


const mapStateToProps = (state) => {
    return {
        date: state.date,
        id: state.id
    }
}

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        clockTicking: () => dispatch(clockTicking(ownProps.id))
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Timer)
