import PropTypes from 'prop-types';

const Header = ({ title }) => {
    return (
        <header>
            <h1>
                {title}
            </h1>
        </header>
    )
}

Header.defaultProps = {
    title: 'ShipVista Water Plants Assessment by Shaheer Khan'
}

Header.propTypes = {
    title: PropTypes.string,
}



export default Header;