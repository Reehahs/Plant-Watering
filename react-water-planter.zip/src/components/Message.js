import PropTypes from 'prop-types';
import { connect } from 'react-redux';



const Message = (props) => {
    return (
        <div className='message'>
            {props.text}
        </div>
    )
}

Message.defaultProps = {
    text: 'Water your plants! 💦🌱'
}

Message.propTypes = {
    text: PropTypes.string,
}



export default connect()(Message)